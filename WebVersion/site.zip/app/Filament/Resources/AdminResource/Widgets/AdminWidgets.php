<?php

namespace App\Filament\Resources\AdminResource\Widgets;

use App\Models\User;

use Filament\Widgets\StatsOverviewWidget as BaseWidget;

class AdminWidgets extends BaseWidget
{
    protected function getStats(): array
    {
        return [
            
        ];
    }
}
